/*
 * Course: DMA 64 - Creative Coding for Mobile Devices
 * Assignment: Assignment Name
 *
 * by Steven Phan, Elena Chen, Janice Chen
 *
 * Initiated: 11/9/2021
 * Last updated: 11/15/2021
 *
 * DEVICE TESTED ON: iPad Pro (9.7-inch)
 *
 * CITATIONS: List all sources you used for this assignment.
 *
 * NOTE:
 *       If ball is too fast, sometimes count wont add.
 *
 *
 * */


import SwiftProcessing
import UIKit


class MySketch: Sketch, SketchDelegate {
    
    var ball: Ball!
    var paddle1: Paddle!
    var paddle2: Paddle!
    var counter1: Counter!
    var counter2: Counter!
    var blink = 0
    var blinkspeed = 10
    var blinker = 255
    var just_won = 0.0
    //**
    var powerUp: PowerBox!
    var showPowerUp = 0
    var titleClickDisappear = 0
    var title: Image!
    var beach: Image!
    
    
    func setup() {
        background(0)
        ball = Ball(sketch: self)
        paddle1 = Paddle(sketch: self, x: 20)
        paddle2 = Paddle(sketch: self, x: width - 20)
        counter1 = Counter(sketch: self)
        counter2 = Counter(sketch: self)
        beach = loadImage("Untitled-2.png")
        title = loadImage("Pong_Title_Screen-01.png")
        imageMode(.center)
        //**
        powerUp = PowerBox(sketch:self, paddle: paddle1, xBox: random(width/4, 3*width/4), yBox: random(height/4, 3*height/4), widthBox: random(50, 100), heightBox: random(50, 100))
        
    }
    
    func draw() {
        
        image(title, width/2, height/2)
        
        if titleClickDisappear == 1 {
            
            background(100,100,255,100)
            image(beach, width/2, height/2)
            hitPaddlefx()
            gamefx()
            winning()
            counter1.display(textoffset: -50)
            counter2.display(textoffset: 50)
            ball.display()
            paddle1.display()
            paddle2.display()
            print (ball.speed.x , ball.acceleration)
            
            //**Power Up box is displayed after 6 secs into playing game
            if showPowerUp > 360 {
                powerUp.display()
            }
            showPowerUp += 1
            powerUp.fxCount += 1
            
            if showPowerUp > 360 && powerUp.checkForBorders(x: ball.x, y: ball.y) {
                powerUpPaddle() // power up effect: paddle shortens for 3 seconds
            }
            
            //powerUp.fxCount = -180 when power up is hit, so when it returns to 0, original paddle settings resume
            if powerUp.fxCount == 0 {
                paddle1.height = 100
                paddle2.height = 100
            }
        }
        
        
    }
    
    
    func touchStarted() {
        
        titleClickDisappear = 1
        
        // "I can only move the paddle, within those bounds, if I exit the bounds, the paddle will cease to move
        // until I re-enter the bounds"
        
        // Left Half Bound  --- Paddle Bound Top -- Top Half Paddle  -- Paddle Bound Bottom -- Bottom Half Paddle
        if touchX < width/2 && touchY > height/4 + paddle1.height/2 && touchY < 3*height/4 - paddle1.height/2{
            paddle1.moveTo(target: touchY)
            if isballCenter(){
                ball.speed = createVector(random(ball.minSpeed, ball.maxSpeed), random(ball.maxSpeedR, ball.maxSpeed))
                
                //** when ball is centered, color alphas will return to zero and speeds that increase alpha return to zero
                //** if the ball is centered, the ball will move upon touchStarted
                just_won = 1
                if just_won == 1 {
                    resetScoreboard()
                }
            }
            //Right Half Bound  --- Paddle Bound Top -- Top Half Paddle  -- Paddle Bound Bottom -- Bottom Half Paddle
        } else if touchX > width/2 && touchY > height/4 + paddle2.height/2 && ((paddle2.height/2) != 0)
                    && touchY < 3*height/4 - paddle2.height/2{
            paddle2.moveTo(target: touchY)
            if isballCenter(){
                ball.speed = createVector(random(ball.maxSpeedR, ball.minSpeedR), random(ball.maxSpeedR, ball.maxSpeed))
                
                //** when ball is centered, color alphas will return to zero and speeds that increase alpha return to zero
                just_won = 1
                if just_won == 1 {
                    resetScoreboard()
                }
            }
        }
        
    }
    
    //** removed ifballCenter from touchMoved() - ball does not need to be at center when paddles are moving or touch is activated. Ball should only be in center when no interaction occuring.
    func touchMoved() {
        //Refer to TouchStarted
        if touchX < width/2 && touchY > height/4 + paddle1.height/2 && touchY < 3*height/4 - paddle1.height/2{
            paddle1.moveTo(target: touchY)
            
            //when paddle2 rightside is clicked and dragged, paddle2 moves according to touchY
        } else if touchX > width/2 && touchY > height/4 + paddle2.height/2 && ((paddle2.height/2) != 0)
                    && touchY < 3*height/4 - paddle2.height/2{
            paddle2.moveTo(target: touchY)
            
        }
        
    }
    
    func isballCenter() -> Bool {
        //** setting all counter.winconditions to 0 allowed the ball to keep moving??
        return ball.x == width/2 && ball.y == height/2 && ball.speed.x == 0 && ball.speed.y == 0
        
    }
    
    func hitPaddle(ball: Ball, paddle: Paddle) -> Bool {
        return
            
            // Refer to Miro Board for Q Diagram of how the bound works.
            
            //Q1
            (ball.y + ball.size/2 > paddle.y - paddle.height/2) &&
            //Q2
            (ball.y - ball.size/2 < paddle.y + paddle.height/2) &&
            //Q3
            (ball.x - ball.size/2 < paddle.x + paddle.width/2) &&
            //Q4
            (ball.x + ball.size/2 > paddle.x - paddle.width/2)
    }
    
    //FX = effects
    
    //** nested if loops
    func hitPaddlefx(){
        // "If the ball hit's the paddle, reverse the ball speed, but also turn on the blink function."
        if hitPaddle(ball: ball, paddle: paddle1) || hitPaddle(ball: ball, paddle: paddle2) {
            ball.reverseX()
            blink = 1
            // "Now that the blink function is on, have this shape's alpha (opacity) decrease over time."
            if blink == 1 {
                blinker = Int(blinker - blinkspeed)
                fill(255, blinker)
                rect(width/2, height/2, width, height/2)
            } // "If the shape's alpha (opacity) = 0, then turn off the blink function, until it hit's a paddle again."
            else if blinker < 0 {
                blink = 0
                blinker = 255
            }
        }
    }
    
    
    func gamefx(){
        // Game bound, Settings, FX, etc.
        noFill()
        stroke(255)
        //        strokeWeight(5)
        //        rect(width/2, height/2, width, height/2)
        strokeWeight(1)
        line(width/2, height/4, width/2, 3*height/4)
    }
    
    //** put into a function so it's cleaner for readability
    func resetScoreboard() {
        counter1.wincondition1 = 0
        counter1.speedbar1 = 0
        counter1.wincondition2 = 0
        counter1.speedbar2 = 0
        counter1.wincondition3 = 0
        counter1.speedbar3 = 0
        counter2.wincondition1 = 0
        counter2.speedbar1 = 0
        counter2.wincondition2 = 0
        counter2.speedbar2 = 0
        counter2.wincondition3 = 0
        counter2.speedbar3 = 0
    }
    
    //** Paddle effects after power up and how to return to original settings
    func powerUpPaddle () {
        ball.reverseX()
        ball.reverseY()
        paddle1.powerUp(powerUpHeight: 30)
        paddle2.powerUp(powerUpHeight: 30)
        
        //after ball hits power up, power up count is reset and has to wait another 3 seconds before another power up
        showPowerUp = 0
        //after ball hits power up, power effect set to -180 to initiate power up countup to 0
        powerUp.fxCount = -180
        
        //resets for next random location of power up box
        powerUp.powerUpLocation()
        
    }
    
    func winning(){
        //Right Side Perspective Winning
        //If the ball makes it to the left, and the first score isn't fully white yet, change the opacity of the first
        //score until it is fully white.
        if ball.x - ball.size/2 < ball.size/2 && counter2.wincondition1 < 255 {
            counter2.speedbar1 = 10
        }
        //If the ball makes it to the left and the second score isn't fully white yet, change the opacity of the second
        //score until it is fully white.
        else if counter2.wincondition1 > 255 && ball.x - ball.size/2 < ball.size/2 && counter2.wincondition2 < 255 {
            counter2.speedbar2 = 10
        }
        //If the ball makes it to the left, and the third score isn't fully white yet, change the opacity of the third
        //score until it is fully white.
        else if counter2.wincondition2 > 255 && ball.x - ball.size/2 < ball.size/2 && counter2.wincondition3 < 255 {
            counter2.wincondition3 = 255
        }
        //If the third score is filled, the game is over and the right player as won.
        if counter2.wincondition3 == 255 {
            ball.x = width/2 ; ball.y = height/2 ; ball.speed.x = 0 ; ball.speed.y = 0
            fill(255)
            text("Right Player Wins", width/2 - 100, 3 * height/4 + 100, width/2 + 100, 3 * height/4 + 100)
            showPowerUp = 0
            
            //** win condition: ball resets to center, congratulatory text appears, power up countup resets 0
        }
        
        
        //Left Side Perspective Winning
        
        //If the ball makes it to the right, and the first score isn't fully white yet, change the opacity of the first
        //score until it is fully white.
        if ball.x + ball.size/2 > width - ball.size/2 && counter1.wincondition1 < 255 {
            counter1.speedbar1 = 10
        }
        //If the ball makes it to the right, and the second score isn't fully white yet, change the opacity of the second
        //score until it is fully white.
        else if counter1.wincondition1 > 255 && ball.x + ball.size/2 > width - ball.size/2 && counter1.wincondition2 < 255 {
            counter1.speedbar2 = 10
        }
        //If the ball makes it to the right, and the third score isn't fully white yet, change the opacity of the third
        //score until it is fully white.
        else if counter1.wincondition2 > 255 && ball.x + ball.size/2 > width - ball.size/2 && counter1.wincondition3 < 255 {
            counter1.wincondition3 = 255
        }
        //If the third score is filled, the game is over and the left player as won.
        if counter1.wincondition3 == 255{
            ball.x = width/2 ; ball.y = height/2 ; ball.speed.x = 0 ; ball.speed.y = 0
            fill(255)
            text("Left Player Wins", width/2 - 100, 3 * height/4 + 100, width/2 + 100, 3 * height/4 + 100)
            showPowerUp = 0
            
            //** win condition: ball resets to center, congratulatory text appears, power up countup resets 0
        }
        
    }
}

class Ball {
    var sketch: Sketch
    
    var size = 20
    var minSpeed = 1
    var maxSpeed = 10
    var minSpeedR = -1
    var maxSpeedR = -10
    var acceleration = 0.0
    
    
    var x: Double
    var y: Double
    var speed: Sketch.Vector
    
    init(sketch: Sketch) {
        self.sketch = sketch
        
        self.x = sketch.width/2
        self.y = sketch.height/2
        
        self.speed = sketch.createVector(0, 0)
        
        
    }
    
    func display() {
        sketch.fill(255)
        sketch.noStroke()
        sketch.circle(x, y, size)
        move()
        checkForWalls()
        
    }
    
    func move() {
        //        x += sketch.constrain(speed.x,1,10)
        x += speed.x
        y += speed.y
    }
    
    func reverseX() {
        
        // If the ball speed is more than max speed (both positive and negative), then have no acceleration.
        
        if speed.x > maxSpeed || speed.x < maxSpeedR{
            acceleration = -1.0
        }
        
        // If the ball speed is less than max speed (both positive and negative), then have acceleration.
        
        else if speed.x < maxSpeed && speed.x > maxSpeedR{
            acceleration = -1.5
        }
        
        
        
        speed.x *= acceleration
        speed.y *= 1.0
    }
    
    func reverseY() {
        speed.y *= -1.0
    }
    
    func checkForWalls() {
        
        // "If left player wins, the ball will start on the CORNER of their screen, with a random speed and angle."
        
        //win condition
        if x + size/2 > sketch.width {
            //CORNER
            x = Double(size) + size
            y = sketch.height/4 + Double(size) + size
            //randomness of angle and speed
            speed = sketch.createVector(sketch.random(minSpeed, maxSpeed), sketch.random(minSpeed, maxSpeed))
        }
        // "If right player wins, the ball will start on the CORNER of their screen, with a random speed and angle."
        
        //win condition
        else if x - size/2 < 0 {
            //corner
            x = sketch.width - Double(size) - size
            y = sketch.height/4 + Double(size) + size
            //randomness of angle and speed
            speed = sketch.createVector(sketch.random(maxSpeedR , minSpeedR), sketch.random(minSpeed, maxSpeed))
            
        }
        
        // " If the ball hit's the bounds of the game (top and bottom), reverse the ball's verticle speed.
        //bottom                                //top
        if y > (3 * sketch.height/4) - size/2 || y < (sketch.height/4 + size/2) {
            reverseY()
        }
    }
    
    
}

class Paddle {
    
    var sketch: Sketch
    var lerpAmount = 0.25
    var x: Double
    var y: Double
    var targetY: Double
    var width = 20
    var height = 100
    
    
    init(sketch: Sketch, x: Double) {
        self.sketch = sketch
        self.x = x
        self.y = sketch.height - 70
        self.targetY = sketch.height/2
    }
    
    func display() {
        y = sketch.constrain(sketch.lerp(y, targetY, lerpAmount), height/2, sketch.height - height/2)
        sketch.fill(255)
        sketch.noStroke()
        sketch.rectMode(.center)
        sketch.rect(x, y, width, height) // rect on left
    }
    
    func moveTo(target: Double) {
        self.targetY = target
    }
    
    //**
    func powerUp(powerUpHeight: Int) {
        self.height = powerUpHeight
    }
    
}

class Counter {
    var sketch : Sketch
    var textoffset = 0.0
    var wincondition1 = 0.0
    var wincondition2 = 0.0
    var wincondition3 = 0.0
    var speedbar1 = 0.0
    var speedbar2 = 0.0
    var speedbar3 = 0.0
    
    
    init(sketch: Sketch) {
        self.sketch = sketch
        self.wincondition1 = 0.0
        self.wincondition2 = 0.0
        self.wincondition3 = 0.0
    }
    
    func display(textoffset: Int){
        
        wincondition1 += speedbar1
        wincondition2 += speedbar2
        wincondition3 += speedbar3
        
        sketch.fill(255, wincondition1)
        sketch.circle(sketch.width/2 + textoffset, sketch.height/4 - 100 , 20)
        sketch.fill(255, wincondition2)
        sketch.circle(sketch.width/2 + 2 * textoffset, sketch.height/4 - 100 , 20)
        sketch.fill(255, wincondition3)
        sketch.circle(sketch.width/2 + 3 * textoffset, sketch.height/4 - 100 , 20)
        
    }
}

//** object Power Up Box
class PowerBox {
    var sketch: Sketch
    
    var x: Double
    var y: Double
    var width: Double
    var height: Double
    var R: Double
    var G: Double
    var B: Double
    var paddle: Paddle
    var randomPowerUp: Double
    var fxCount: Double
    
    
    
    init(sketch: Sketch, paddle: Paddle, xBox: Double, yBox: Double, widthBox: Double, heightBox: Double){
        self.sketch = sketch
        self.paddle = paddle
        self.x = xBox
        self.y = yBox
        self.width = widthBox
        self.height = heightBox
        self.randomPowerUp = 0
        self.fxCount = 0
        
        //start with pastel yellow color
        self.R = 255
        self.G = 255
        self.B = 51
        
        
    }
    
    func display() {
        
        
        sketch.fill(self.R, self.G, self.B)
        sketch.rectMode(.center)
        sketch.rect(self.x, self.y, self.width, self.height)
        
        
        
        //**could set range of colors every time power up is displayed? sketch.random
        self.R = 255
        self.G = 255
        self.B = 51
        
        //**randomly selects the type of power up that is given between 3 types
        //        self.randomPowerUp = sketch.random(1, 4)
        //
    }
    
    //range of locations for the power up box to show up within the bounds of pool
    func powerUpLocation () {
        self.x = sketch.random(150, sketch.width - 150)
        self.y = sketch.random(sketch.height/4 + 50, 3*sketch.height/4 - 50)
        self.width = sketch.random(50, 100)
        self.height = sketch.random(50, 100)
        
    }
    
    
    func checkForBorders(x: Double, y: Double) -> Bool {
        // tells you if the input of ball.x and ball.y hits the power up box or not
        return ((x > self.x - self.width/2) && (x < self.x + self.width/2) &&
                    (y > self.y - self.height/2) && (y < self.y + self.height/2))
        
    }
    
}



